CaptureEgg Pokeball Resource Pack — Minecraft Java 26.2

安裝：把本 ZIP 放入 .minecraft/resourcepacks，不要解壓，然後在遊戲「選項 → 資源包」啟用。
請選擇與你的 Minecraft Java 客戶端版本完全相同的 26.2 專用包。
需要 CaptureEgg 插件 1.1.9。資源包只負責材質；伺服器插件需另外安裝。
若停留在資源包清單，先按「完成」返回遊戲，再重新打開清單。
